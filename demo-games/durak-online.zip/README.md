# Durak Online — SUPER CUBE server game example

An adaptive, server-authoritative multiplayer Durak demonstrator for 2–6 players. It uses Node.js built-ins only; no npm dependencies are required.

## Upload format

Upload this folder as a ZIP to SUPER CUBE. Required metadata lives under `media/`:

```text
index.html                 # public room directory / lobby
game.html                  # one room: connect, waiting lobby, and match table
 client.js                 # frontend interaction and API client
 style.css                 # adaptive portrait UI and animations
 package.json              # start + test scripts; no dependencies
 runtime.txt               # server
 server/index.js           # authoritative room/game state
 test/server.test.cjs      # API contract tests
 media/title.txt           # English title
 media/description.ru.txt
 media/description.en.txt
 media/tags.ru.txt
 media/tags.en.txt
 media/capsule.jpg         # exactly 630 × 500
 media/screenshots/table.jpg
```

## How to play

1. Open the game's lobby. Choose a display name and player count.
2. Optionally enable **Make this room private**. Private rooms do not appear in the public room list and require a high-entropy invite token in the link.
3. Create the room. The host is redirected to `game.html`; send the invitation from the table lobby using native device sharing, copy link, Telegram, WhatsApp, or email.
4. Guests opening an invitation choose their own display name and join the table. A host can start when at least two players are connected.
5. Drag a card from your hand onto the tabletop to attack, or onto an uncovered attacking card to defend. The dragged card follows the pointer with an elevated shadow and a highlighted target. If released outside a valid target it returns to the hand. Touch screens use Pointer Events; action buttons remain available as accessible alternatives.
6. During attack phase, the designated attacker may add cards whose ranks are already on the table, up to the defender's hand size at the start of the round and a six-card cap. Once the attacker finishes, the defender can beat every card, or take the table.
7. The next round rotates the previous defender into the attacker role when possible. Finished matches disappear from the public open-table list. The list contains only public waiting rooms with available seats.

## Runtime contract

- Listens on `0.0.0.0:${PORT || 3000}` as required by the SUPER CUBE runtime.
- Static files are served from the game root; `server/` is not served as static content.
- Endpoints: `GET /health`, `GET /api/rooms`, `POST /api/rooms`, `POST /api/rooms/:id/join`, `POST /api/rooms/:id/leave`, `GET /api/rooms/:id?pid=...`, `POST /api/rooms/:id/start`, `POST /api/rooms/:id/action`.
- Public room discovery returns only public rooms in waiting state with an available seat. Private room joins require the server-issued `inviteToken`.
- Match state and cards remain on the server. The client receives only its own hand and the other players' hand counts.
- Rooms are stored in process memory. Restarting the runtime resets active tables; persistent/recoverable matches would require a durable store and reconnect policy.
- The room `pid` is a per-browser session identifier for this demonstrator, not a verified platform account identity. Do not use this sample as a ranked/real-money game without stronger identity binding, abuse controls, rate limits, and durable state.
- Polling is used instead of WebSockets so reconnect is simple and doesn't require upgrades through every reverse proxy.

## Game rules in this demonstrator

- 36-card deck, ranks six through ace, four suits.
- Lowest trump in the initial hand starts; if none is found, the starter is random.
- The current attacker begins a round. Extra attacks must match a rank already on the table. The defender can beat an attack with a higher card of the same suit or a trump; trump beats a non-trump.
- The defender can take all table cards or finish a round once all attacks are beaten.
- Players draw back up to six cards while the deck remains. On round resolution, roles rotate so the former defender becomes the next attacker when they remain eligible.
- Last player with cards after the deck is exhausted is marked Durak. This is a simplified multiplayer demonstrator, not a tournament-complete rules implementation.

## Presence, host transfer and sharing

The room lobby includes a responsive player table with nickname, public game ID and host status. Invitation links are presented in a centered dialog; Copy link copies to clipboard and shows a toast. The table header intentionally omits share and language controls. Both lobby and match screens have a Leave room action. `pagehide` sends a best-effort leave beacon, and the server removes stale players after 30 seconds. If no players remain, the room is deleted. If the host leaves, the next remaining player becomes host.

## Local tests

Use Node.js 20 or newer:

```bash
npm test
npm start
```

The test suite starts a temporary server and checks separate lobby/table pages, private invite enforcement, attacker rotation, removal of running rooms from public discovery, and drag/share client hooks. No database, Docker, or external package installation is needed for the standalone rules/API tests.
