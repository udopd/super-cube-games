'use strict';
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const ROOT = path.resolve(__dirname, '..');
const PORT = Number(process.env.PORT || 3000);
const rooms = new Map();
const PRESENCE_TIMEOUT_MS = 30_000;
const suits = ['♠','♥','♦','♣'];
const ranks = ['6','7','8','9','10','J','Q','K','A'];
const rankValue = Object.fromEntries(ranks.map((rank, i) => [rank, i]));
const mime = {'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.jpg':'image/jpeg','.jpeg':'image/jpeg','.png':'image/png','.gif':'image/gif','.svg':'image/svg+xml','.webp':'image/webp'};
function respond(res, status, data) { const body = Buffer.from(JSON.stringify(data));res.writeHead(status,{'content-type':'application/json; charset=utf-8','content-length':body.length,'cache-control':'no-store','x-content-type-options':'nosniff'});res.end(body); }
function cleanName(value) { return String(value || 'Player').replace(/[<>\u0000-\u001f]/g,'').trim().slice(0,24) || 'Player'; }
function cleanPid(value) { const pid=String(value||'');return /^[a-zA-Z0-9_-]{8,80}$/.test(pid)?pid:''; }
function makeId(){return crypto.randomBytes(3).toString('hex').toUpperCase();}
function makeInviteToken(){return crypto.randomBytes(24).toString('base64url');}
function makeDeck(){const deck=[];for(const suit of suits)for(const rank of ranks)deck.push({id:`${rank}-${suit}`,rank,suit,label:`${rank}${suit}`});for(let i=deck.length-1;i>0;i--){const j=crypto.randomInt(i+1);[deck[i],deck[j]]=[deck[j],deck[i]];}return deck;}
function roomById(id){return rooms.get(String(id||'').toUpperCase());}
function playerIndex(room,pid){return room.players.findIndex(p=>p.id===pid);}
function publicPlayerId(pid){return `SC-${String(pid||'').replace(/[^a-z0-9]/gi,'').slice(0,8).toUpperCase()}`;}
function removePlayer(room,pid){
  const index=playerIndex(room,pid); if(index<0)return;
  const oldPlayers=room.players.slice();
  const oldAttackerId=oldPlayers[room.attackerIndex]?.id;
  const oldDefenderId=oldPlayers[room.defenderIndex]?.id;
  const departing=room.players[index];
  if(room.status==='playing'&&departing.hand?.length)room.discard.push(...departing.hand);
  room.players.splice(index,1);
  if(!room.players.length){rooms.delete(room.id);return;}
  if(room.hostId===pid){room.hostId=room.players[index % room.players.length].id;}
  const remap=(oldId,fallback)=>{
    const mapped=room.players.findIndex(p=>p.id===oldId);
    return mapped>=0?mapped:Math.min(index,room.players.length-1);
  };
  room.attackerIndex=remap(oldAttackerId,room.attackerIndex);
  room.defenderIndex=remap(oldDefenderId,room.defenderIndex);
  if(room.players.length<2){
    if(room.status==='playing'){
      room.status='waiting';room.phase='attack';room.deck=[];room.trump=null;room.table=[];room.discard=[];room.lastRoundOutcome='';room.durakIndex=-1;
      for(const player of room.players)player.hand=[];
      room.message='Waiting for another player.';
    }
    room.attackerIndex=0;room.defenderIndex=1;room.defenderHandAtStart=0;
    return;
  }
  if(room.attackerIndex===room.defenderIndex){room.defenderIndex=(room.attackerIndex+1)%room.players.length;}
  if(room.status==='playing'){
    room.attackerIndex=nextEligible(room,room.attackerIndex);
    if(room.defenderIndex===room.attackerIndex)room.defenderIndex=nextEligible(room,room.attackerIndex);
    room.defenderHandAtStart=Math.max(room.table.length,room.players[room.defenderIndex]?.hand.length||0);
    room.message=`A player left. ${room.players[room.attackerIndex]?.name||'Next player'} is now the attacker.`;
  }
}
function cleanupStaleRooms(now=Date.now()){
  for(const room of [...rooms.values()]){
    const stale=room.players.filter(player=>!player.lastSeenAt||now-player.lastSeenAt>PRESENCE_TIMEOUT_MS);
    for(const player of stale)removePlayer(room,player.id);
  }
}
const presenceSweep=setInterval(()=>cleanupStaleRooms(),5_000);
presenceSweep.unref();
function activeIndices(room){return room.players.map((p,i)=>p.hand.length?i:-1).filter(i=>i>=0);}
function nextEligible(room,from){for(let step=1;step<=room.players.length;step++){const i=(from+step)%room.players.length;if(room.deck.length||room.players[i].hand.length)return i;}return from;}
function drawCards(room){if(!room.deck.length)return;for(let step=0;step<room.players.length;step++){const i=(room.attackerIndex+step)%room.players.length;const p=room.players[i];while(p.hand.length<6&&room.deck.length)p.hand.push(room.deck.pop());}}
function finishIfOver(room){if(room.deck.length)return false;const alive=activeIndices(room);if(alive.length<=1){room.status='finished';room.phase='finished';room.durakIndex=alive.length?alive[0]:-1;room.message=room.durakIndex>=0?`${room.players[room.durakIndex].name} is Durak.`:'The match ended in a draw.';return true;}return false;}
function setDefenderLimit(room){room.defenderHandAtStart=room.players[room.defenderIndex]?.hand.length||0;}
function resetRound(room,defenderTook){const previousDefender=room.defenderIndex;room.lastRoundOutcome=defenderTook?'taken':'beaten';room.table=[];room.attackerIndex=(room.deck.length||room.players[previousDefender]?.hand.length)?previousDefender:nextEligible(room,previousDefender);room.defenderIndex=nextEligible(room,room.attackerIndex);drawCards(room);setDefenderLimit(room);if(finishIfOver(room)){if(defenderTook)room.message=`Defender took the cards. ${room.message}`;return;}room.phase='attack';room.message=defenderTook?'Defender took the cards. The next player attacks.':'All cards beaten. The next player attacks.';}
function makeRoomState(room,pid){const me=room.players[playerIndex(room,pid)];if(!me)return null;const turnIndex=room.phase==='attack'?room.attackerIndex:room.defenderIndex;return {roomId:room.id,status:room.status,maxPlayers:room.maxPlayers,isPrivate:room.isPrivate,lastRoundOutcome:room.lastRoundOutcome||'',hostId:room.hostId,isHost:room.hostId===pid,players:room.players.map((p,i)=>({id:p.id,publicId:p.publicId||publicPlayerId(p.id),name:p.name,handCount:p.hand.length,ready:p.ready,online:!!p.lastSeenAt&&Date.now()-p.lastSeenAt<=PRESENCE_TIMEOUT_MS})),hand:me.hand.map(c=>({...c})).sort((a,b)=>rankValue[a.rank]-rankValue[b.rank]),deckCount:room.deck.length,trump:room.trump,table:room.table.map(pair=>({attack:pair.attack,defense:pair.defense})),phase:room.phase,turnPlayerId:room.status==='playing'&&turnIndex>=0?room.players[turnIndex].id:null,isDefender:room.status==='playing'&&room.players[room.defenderIndex]?.id===pid,isAttacker:room.status==='playing'&&room.players[room.attackerIndex]?.id===pid,canAddAttack:room.status==='playing'&&room.players[room.attackerIndex]?.id===pid&&room.phase==='attack'&&room.table.length<(room.defenderHandAtStart||0)&&room.table.length<6,attackerId:room.players[room.attackerIndex]?.id||null,defenderId:room.players[room.defenderIndex]?.id||null,message:room.message,durakName:room.durakIndex>=0?room.players[room.durakIndex].name:''};}
function beats(attack,defense,trumpSuit){return (attack.suit===defense.suit&&rankValue[defense.rank]>rankValue[attack.rank])||(defense.suit===trumpSuit&&attack.suit!==trumpSuit);}
function startRoom(room,pid){if(room.hostId!==pid)throw Error('Only the room host can start the game.');if(room.status!=='waiting')throw Error('This game has already started.');if(room.players.length<2)throw Error('At least two players are needed.');room.deck=makeDeck();room.trump=room.deck[0];room.players.forEach(p=>p.hand=[]);const openingHand=room.players.length===6?5:6;for(let n=0;n<openingHand;n++)for(const p of room.players)p.hand.push(room.deck.pop());room.discard=[];room.table=[];room.lastRoundOutcome='';let low=null,starter=-1;for(let i=0;i<room.players.length;i++){const card=room.players[i].hand.filter(c=>c.suit===room.trump.suit).sort((a,b)=>rankValue[a.rank]-rankValue[b.rank])[0];if(card&&(!low||rankValue[card.rank]<rankValue[low.rank])){low=card;starter=i;}}if(starter<0)starter=crypto.randomInt(room.players.length);room.attackerIndex=starter;room.defenderIndex=nextEligible(room,starter);room.status='playing';room.phase='attack';setDefenderLimit(room);room.message=`${room.players[room.attackerIndex].name} attacks first.`;}
function performAction(room,body){const pid=cleanPid(body.pid);const index=playerIndex(room,pid);if(index<0)throw Error('You are not a member of this room.');if(room.status!=='playing')throw Error('The game is not in progress.');const action=String(body.action||'');const attacker=room.players[room.attackerIndex];const defender=room.players[room.defenderIndex];if(action==='attack'){
  if(attacker.id!==pid)throw Error('Only the current attacker may add a card.');if(room.phase!=='attack')throw Error('The attack is closed. Wait for the next round.');if(room.table.length>=(room.defenderHandAtStart||defender.hand.length)||room.table.length>=6)throw Error('The defender cannot be attacked with more cards.');const cardIndex=attacker.hand.findIndex(c=>c.id===body.cardId);if(cardIndex<0)throw Error('That card is not in your hand.');const card=attacker.hand[cardIndex];if(room.table.length&&![...room.table.flatMap(p=>[p.attack,p.defense].filter(Boolean)).map(c=>c.rank)].includes(card.rank))throw Error('An additional attack must match a rank already on the table.');attacker.hand.splice(cardIndex,1);room.table.push({attack:card,defense:null});room.message=`${attacker.name} attacked with ${card.label}.`;return;
 }
 if(action==='end-attack') {if(attacker.id!==pid)throw Error('Only the attacker may finish the attack.');if(room.phase!=='attack')throw Error('The attack is already closed.');if(!room.table.length)throw Error('Play at least one card first.');room.phase='defense';room.message=`${defender.name}, defend or take the cards.`;return;}
 if(action==='defend') {if(defender.id!==pid)throw Error('Only the defender may defend.');if(room.phase!=='defense')throw Error('Wait until the attacker finishes their attack.');const rowIndex=Number(body.tableIndex);const pair=room.table[rowIndex];if(!pair||pair.defense)throw Error('Choose an uncovered attacking card.');const cardIndex=defender.hand.findIndex(c=>c.id===body.cardId);if(cardIndex<0)throw Error('That card is not in your hand.');const card=defender.hand[cardIndex];if(!beats(pair.attack,card,room.trump.suit))throw Error('That card cannot beat this attack.');defender.hand.splice(cardIndex,1);pair.defense=card;room.message=`${defender.name} defended ${pair.attack.label}.`;return;}
 if(action==='take') {if(defender.id!==pid)throw Error('Only the defender can take the cards.');if(room.phase!=='defense')throw Error('Wait until the attacker finishes their attack.');for(const pair of room.table){defender.hand.push(pair.attack);if(pair.defense)defender.hand.push(pair.defense);}resetRound(room,true);return;}
 if(action==='finish') {if(defender.id!==pid)throw Error('Only the defender can finish the round.');if(room.phase!=='defense')throw Error('Wait until the attacker finishes their attack.');if(!room.table.length||room.table.some(pair=>!pair.defense))throw Error('Every attacking card must be beaten first.');for(const pair of room.table){room.discard.push(pair.attack,pair.defense);}resetRound(room,false);return;}
 throw Error('Unknown action.');
}
async function bodyJson(req){const chunks=[];let size=0;for await(const chunk of req){size+=chunk.length;if(size>20*1024)throw Error('Request body is too large.');chunks.push(chunk);}if(!chunks.length)return {};try{return JSON.parse(Buffer.concat(chunks).toString('utf8'));}catch{throw Error('Invalid JSON body.');}}
function serveStatic(pathname,res){let requested=decodeURIComponent(pathname||'/');if(requested==='/'||requested==='/')requested='/index.html';requested=requested.replace(/^\/+/, '');const resolved=path.resolve(ROOT,requested);if(!resolved.startsWith(ROOT+path.sep)||resolved.startsWith(path.join(ROOT,'server')+path.sep)){res.writeHead(404);res.end('Not found');return;}fs.stat(resolved,(err,stat)=>{if(err||!stat.isFile()||stat.size>6*1024*1024){res.writeHead(404);res.end('Not found');return;}const ext=path.extname(resolved).toLowerCase();res.writeHead(200,{'content-type':mime[ext]||'application/octet-stream','cache-control':ext==='.html'?'no-store':'public, max-age=120','x-content-type-options':'nosniff'});fs.createReadStream(resolved).pipe(res);});}
const server=http.createServer(async(req,res)=>{const url=new URL(req.url,'http://runtime.local');const pathname=url.pathname.toLowerCase();try{
  if(req.method==='GET'&&pathname==='/health')return respond(res,200,{ok:true});
  if(req.method==='GET'&&pathname==='/api/rooms'){cleanupStaleRooms();return respond(res,200,{rooms:[...rooms.values()].filter(r=>!r.isPrivate&&r.status==='waiting'&&r.players.length<r.maxPlayers).map(r=>({id:r.id,hostName:r.players.find(p=>p.id===r.hostId)?.name||'Player',players:r.players.length,maxPlayers:r.maxPlayers}))});}
  if(req.method==='POST'&&pathname==='/api/rooms'){const body=await bodyJson(req);const pid=cleanPid(body.pid);if(!pid)return respond(res,400,{error:'Invalid player session.'});const maxPlayers=Number(body.maxPlayers);if(!Number.isInteger(maxPlayers)||maxPlayers<2||maxPlayers>6)return respond(res,400,{error:'Room size must be between 2 and 6 players.'});let id=makeId();while(rooms.has(id))id=makeId();const inviteToken=makeInviteToken();const isPrivate=Boolean(body.isPrivate);const player={id:pid,publicId:publicPlayerId(pid),name:cleanName(body.name),hand:[],ready:true,lastSeenAt:Date.now()};rooms.set(id,{id,inviteToken,isPrivate,lastRoundOutcome:'',hostId:pid,maxPlayers,players:[player],deck:[],trump:null,discard:[],table:[],attackerIndex:0,defenderIndex:1,defenderHandAtStart:0,status:'waiting',phase:'attack',message:'Waiting for players.',durakIndex:-1,createdAt:Date.now()});return respond(res,201,{roomId:id,inviteToken,isPrivate});}
  const joinMatch=pathname.match(/^\/api\/rooms\/([a-z0-9]+)\/join$/);if(req.method==='POST'&&joinMatch){cleanupStaleRooms();const room=roomById(joinMatch[1]);if(!room)return respond(res,404,{error:'Room not found.'});const body=await bodyJson(req);const pid=cleanPid(body.pid);if(!pid)return respond(res,400,{error:'Invalid player session.'});if(room.isPrivate&&body.inviteToken!==room.inviteToken)return respond(res,403,{error:'This is a private room. Open the invitation link to join.'});let player=room.players.find(p=>p.id===pid);if(!player){if(room.status!=='waiting')return respond(res,409,{error:'This game has already started.'});if(room.players.length>=room.maxPlayers)return respond(res,409,{error:'This room is full.'});player={id:pid,publicId:publicPlayerId(pid),name:cleanName(body.name),hand:[],ready:true,lastSeenAt:Date.now()};room.players.push(player);}else{player.lastSeenAt=Date.now();player.name=cleanName(body.name||player.name);}return respond(res,200,{roomId:room.id,isPrivate:room.isPrivate});}
  const leaveMatch=pathname.match(/^\/api\/rooms\/([a-z0-9]+)\/leave$/);if(req.method==='POST'&&leaveMatch){const room=roomById(leaveMatch[1]);if(!room)return respond(res,404,{error:'Room not found.'});const body=await bodyJson(req);const pid=cleanPid(body.pid);const index=playerIndex(room,pid);if(index<0)return respond(res,200,{ok:true});removePlayer(room,pid);return respond(res,200,{ok:true,roomDeleted:!rooms.has(room.id)});}
  const roomMatch=pathname.match(/^\/api\/rooms\/([a-z0-9]+)$/);if(req.method==='GET'&&roomMatch){cleanupStaleRooms();const room=roomById(roomMatch[1]);if(!room)return respond(res,404,{error:'Room not found.'});const pid=cleanPid(url.searchParams.get('pid'));const onlinePlayer=room.players[playerIndex(room,pid)];if(onlinePlayer){onlinePlayer.lastSeenAt=Date.now();onlinePlayer.publicId=onlinePlayer.publicId||publicPlayerId(pid);}const state=makeRoomState(room,pid);if(!state)return respond(res,403,{error:'Join this room first.'});return respond(res,200,{state});}
  const startMatch=pathname.match(/^\/api\/rooms\/([a-z0-9]+)\/start$/);if(req.method==='POST'&&startMatch){const room=roomById(startMatch[1]);if(!room)return respond(res,404,{error:'Room not found.'});const body=await bodyJson(req);try{startRoom(room,cleanPid(body.pid));return respond(res,200,{ok:true});}catch(e){return respond(res,400,{error:e.message});}}
  const actionMatch=pathname.match(/^\/api\/rooms\/([a-z0-9]+)\/action$/);if(req.method==='POST'&&actionMatch){const room=roomById(actionMatch[1]);if(!room)return respond(res,404,{error:'Room not found.'});const body=await bodyJson(req);try{performAction(room,body);return respond(res,200,{ok:true});}catch(e){return respond(res,400,{error:e.message});}}
  if(req.method==='GET')return serveStatic(url.pathname,res);
  return respond(res,404,{error:'Endpoint not found.'});
}catch(e){return respond(res,e.message==='Request body is too large.'?413:400,{error:e.message||'Request failed.'});}});
server.listen(PORT,'0.0.0.0',()=>console.log(`Durak server runtime listening on 0.0.0.0:${PORT}`));
