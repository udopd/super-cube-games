'use strict';
const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const { spawn } = require('node:child_process');
const net = require('node:net');
const path = require('node:path');
const { once } = require('node:events');
let proc, base, logs='';
async function freePort(){return await new Promise((resolve,reject)=>{const s=net.createServer();s.once('error',reject);s.listen(0,'127.0.0.1',()=>{const p=s.address().port;s.close(()=>resolve(p));});});}
async function waitForServer(){for(let i=0;i<100;i++){if(proc.exitCode!==null)throw new Error(`Test server exited: ${logs}`);try{const r=await fetch(`${base}/health`);if(r.ok)return;}catch{}await new Promise(r=>setTimeout(r,75));}throw new Error(`Test server did not start: ${logs}`);}
async function api(route,method='GET',body){const r=await fetch(`${base}${route}`,{method,headers:body?{'content-type':'application/json'}:{},body:body?JSON.stringify(body):undefined});const data=await r.json().catch(()=>({}));return {status:r.status,data};}
const pid=(label)=>`${label}-${cryptoRandom()}`;
function cryptoRandom(){return Math.random().toString(36).slice(2,13);}
async function createRoom(name,isPrivate=false){const playerId=pid(name);const r=await api('/api/rooms','POST',{pid:playerId,name,maxPlayers:2,isPrivate});assert.equal(r.status,201);return { ...r.data, playerId, name };}
let port;
before(async()=>{port=await freePort();base=`http://127.0.0.1:${port}`;proc=spawn(process.execPath,[path.join(__dirname,'../server/index.js')],{env:{...process.env,PORT:String(port)},stdio:['ignore','pipe','pipe']});proc.stdout.on('data',x=>logs+=x.toString());proc.stderr.on('data',x=>logs+=x.toString());await waitForServer();});
after(async()=>{if(proc&&!proc.killed){proc.kill('SIGTERM');await Promise.race([once(proc,'exit'),new Promise(r=>setTimeout(r,500))]);}});

test('lobby and match are separate static pages',async()=>{const a=await fetch(`${base}/`),b=await fetch(`${base}/game.html`);assert.equal(a.status,200);assert.match(await a.text(),/data-page="lobby"/);assert.equal(b.status,200);assert.match(await b.text(),/data-page="game"/);});

test('private rooms are not listed and require an invite token',async()=>{const room=await createRoom('privateHost',true);const list=await api('/api/rooms');assert.equal(list.status,200);assert.equal(list.data.rooms.some(r=>r.id===room.roomId),false);const noToken=await api(`/api/rooms/${room.roomId}/join`,'POST',{pid:pid('guestNoToken'),name:'Intruder'});assert.equal(noToken.status,403);const withToken=await api(`/api/rooms/${room.roomId}/join`,'POST',{pid:pid('guestWithToken'),name:'Friend',inviteToken:room.inviteToken});assert.equal(withToken.status,200);});

test('players alternate attack role after each completed round',async()=>{const room=await createRoom('rotationHost');const guestId=pid('rotationGuest');assert.equal((await api(`/api/rooms/${room.roomId}/join`,'POST',{pid:guestId,name:'Guest'})).status,200);assert.equal((await api(`/api/rooms/${room.roomId}/start`,'POST',{pid:room.playerId})).status,200);const getState=async id=>(await api(`/api/rooms/${room.roomId}?pid=${encodeURIComponent(id)}`)).data.state;const states=[await getState(room.playerId),await getState(guestId)];const attacker=states.find(s=>s.isAttacker);const defender=states.find(s=>s.isDefender);assert.ok(attacker&&defender);const attackerPid=attacker.players.find(p=>p.name===attacker.hand&&false)?.id || (attacker.isHost?room.playerId:guestId);const defenderPid=defender.isHost?room.playerId:guestId;assert.equal((await api(`/api/rooms/${room.roomId}/action`,'POST',{pid:attackerPid,action:'attack',cardId:attacker.hand[0].id})).status,200);assert.equal((await api(`/api/rooms/${room.roomId}/action`,'POST',{pid:attackerPid,action:'end-attack'})).status,200);assert.equal((await api(`/api/rooms/${room.roomId}/action`,'POST',{pid:defenderPid,action:'take'})).status,200);const stateA=await getState(room.playerId),stateB=await getState(guestId);const nextAttacker=stateA.isAttacker?room.playerId:stateB.isAttacker?guestId:'';assert.equal(nextAttacker,defenderPid);});

test('waiting public rooms are listed and running rooms disappear',async()=>{const room=await createRoom('listedHost');assert.equal((await api('/api/rooms')).data.rooms.some(r=>r.id===room.roomId),true);const guestId=pid('listedGuest');await api(`/api/rooms/${room.roomId}/join`,'POST',{pid:guestId,name:'Guest'});await api(`/api/rooms/${room.roomId}/start`,'POST',{pid:room.playerId});assert.equal((await api('/api/rooms')).data.rooms.some(r=>r.id===room.roomId),false);});

test('client implements pointer drag-and-drop and invite sharing',async()=>{const client=await (await fetch(`${base}/client.js`)).text();assert.match(client,/pointerdown/);assert.match(client,/pointermove/);assert.match(client,/pointerup/);assert.match(client,/navigator\.share/);assert.match(client,/isPrivate/);});


test('host is transferred when leaving and room is deleted after last player leaves',async()=>{
  const room=await createRoom('ownerLeave');
  const guestId=pid('guestStays');
  assert.equal((await api(`/api/rooms/${room.roomId}/join`,'POST',{pid:guestId,name:'Next host'})).status,200);
  assert.equal((await api(`/api/rooms/${room.roomId}/leave`,'POST',{pid:room.playerId})).status,200);
  const guestState=await api(`/api/rooms/${room.roomId}?pid=${encodeURIComponent(guestId)}`);
  assert.equal(guestState.status,200);
  assert.equal(guestState.data.state.isHost,true);
  assert.equal(guestState.data.state.players.length,1);
  assert.equal((await api(`/api/rooms/${room.roomId}/leave`,'POST',{pid:guestId})).status,200);
  const list=await api('/api/rooms');
  assert.equal(list.data.rooms.some(item=>item.id===room.roomId),false);
  assert.equal((await api(`/api/rooms/${room.roomId}?pid=${encodeURIComponent(guestId)}`)).status,404);
});

test('share dialog and draggable card styles are present; match header has no share or language toggle',async()=>{
  const html=await (await fetch(`${base}/game.html`)).text();
  const css=await (await fetch(`${base}/style.css`)).text();
  const client=await (await fetch(`${base}/client.js`)).text();
  assert.doesNotMatch(html,/id="shareInvite"/);
  assert.doesNotMatch(html,/id="langToggle"/);
  assert.match(html,/id="leaveRoom"/);
  assert.match(html,/id="leaveLobbyRoom"/);
  assert.match(css,/\.playing-card\.drag-ghost/);
  assert.match(css,/\.share-panel:not\(\[hidden\]\)/);
  assert.match(css,/\.durak-toast/);
  assert.match(client,/navigator\.sendBeacon/);
  assert.match(client,/publicId/);
});
